'use client'

export default function ErrorPage({ reset }: { reset: () => void }) {
  return <div className="not-found section-shell" role="alert"><span>24</span><p>Đường truyền vừa gián đoạn.</p><h1>Chưa thể tải nội dung.</h1><button className="button button-dark" onClick={reset} type="button">Thử lại</button></div>
}
