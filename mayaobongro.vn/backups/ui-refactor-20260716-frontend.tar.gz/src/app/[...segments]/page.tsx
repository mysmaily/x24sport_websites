import { ArrowLeft, ArrowUpRight, MessageCircle } from 'lucide-react'
import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { notFound } from 'next/navigation'

import { JsonLd } from '@/components/json-ld'
import { ProductGrid } from '@/components/product-grid'
import { getProducts, resolveContentPath, resolveProductPath } from '@/lib/cms'
import { canonical, excerpt, SITE_URL, ZALO_URL } from '@/lib/site'

export const dynamic = 'force-dynamic'

function pathFrom(segments: string[]) {
  const encoded = segments.map((segment) => {
    let decoded = segment
    try {
      decoded = decodeURIComponent(segment)
    } catch {
      // Preserve malformed legacy segments so the normal 404 path handles them.
    }
    return encodeURIComponent(decoded).replace(/%[0-9A-F]{2}/g, (token) => token.toLowerCase())
  })
  return `/${encoded.join('/')}/`
}

export async function generateMetadata({ params }: { params: Promise<{ segments: string[] }> }): Promise<Metadata> {
  const { segments } = await params
  const path = pathFrom(segments)
  const product = await resolveProductPath(path)
  if (product) return {
    title: product.name,
    description: excerpt(product.shortDescription || product.name, 160),
    alternates: { canonical: path },
    openGraph: { title: product.name, description: excerpt(product.shortDescription, 160), images: product.legacyImages?.[0]?.url ? [product.legacyImages[0].url] : [] },
  }
  const content = await resolveContentPath(path)
  if (content) return { title: content.title, description: excerpt(content.excerpt, 160), alternates: { canonical: path } }
  return { title: 'Không tìm thấy nội dung', robots: { index: false, follow: false } }
}

export default async function LegacyRoutePage({ params }: { params: Promise<{ segments: string[] }> }) {
  const { segments } = await params
  const path = pathFrom(segments)
  const product = await resolveProductPath(path)
  if (product) {
    const image = product.legacyImages?.[0]
    const related = await getProducts({ limit: 4 })
    return (
      <>
        <JsonLd data={{ '@context': 'https://schema.org', '@type': 'Product', name: product.name, description: excerpt(product.shortDescription || product.name, 300), image: product.legacyImages?.map((item) => item.url) || [], url: canonical(path), brand: { '@type': 'Brand', name: 'X24 Sport' } }} />
        <article className="product-page section-shell">
          <nav className="breadcrumbs" aria-label="Đường dẫn"><Link href="/">Trang chủ</Link><span>/</span><Link href="/san-pham/">Mẫu áo</Link><span>/</span><span>{product.name}</span></nav>
          <div className="product-hero">
            <div className="product-gallery">
              {image?.url ? <Image alt={image.alt || product.name} fill priority sizes="(max-width: 900px) 100vw, 55vw" src={image.url} /> : <div className="image-fallback">24</div>}
              <span className="gallery-stamp">X24 / BASKETBALL</span>
            </div>
            <div className="product-summary">
              <p className="eyebrow">Mẫu đồng phục bóng rổ</p>
              <h1>{product.name}</h1>
              {product.shortDescription ? <p className="product-lead">{product.shortDescription}</p> : null}
              <div className="product-note"><b>Thiết kế theo yêu cầu</b><span>Trao đổi màu sắc, logo, tên và số trước khi đặt may.</span></div>
              <a className="button button-orange button-wide" href={ZALO_URL} rel="noreferrer" target="_blank"><MessageCircle /> Gửi mẫu này qua Zalo</a>
              <a className="text-link text-link-large" href="tel:0989353247">Gọi 0989 353 247 <ArrowUpRight /></a>
            </div>
          </div>
          {product.contentHtml ? <section className="product-content"><div className="content-kicker"><span>Thông tin mẫu</span><b>DETAILS / {product.slug.slice(-10).toUpperCase()}</b></div><div className="prose" dangerouslySetInnerHTML={{ __html: product.contentHtml }} /></section> : null}
        </article>
        <section className="related section-shell"><div className="section-heading"><div><p className="eyebrow">Tiếp tục khám phá</p><h2>Mẫu mới cập nhật.</h2></div><Link className="text-link text-link-large" href="/san-pham/">Tất cả mẫu <ArrowUpRight /></Link></div><ProductGrid products={related.docs.filter((item) => item.id !== product.id).slice(0, 4)} /></section>
      </>
    )
  }

  const content = await resolveContentPath(path)
  if (!content) notFound()
  return (
    <article className="content-page section-shell">
      <Link className="back-link" href="/"><ArrowLeft /> Trang chủ</Link>
      <header><p className="eyebrow">{content.kind === 'post' ? 'Court notes' : 'MayAoBongRo.vn'}</p><h1>{content.title}</h1>{content.excerpt ? <p>{content.excerpt}</p> : null}</header>
      {content.contentHtml ? <div className="prose" dangerouslySetInnerHTML={{ __html: content.contentHtml }} /> : <div className="empty-state">Nội dung đang được cập nhật.</div>}
    </article>
  )
}
