import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'

export default function NotFound() {
  return <div className="not-found section-shell"><span>404</span><p>Đường bóng đã ra ngoài sân.</p><h1>Không tìm thấy trang bạn cần.</h1><Link className="button button-dark" href="/"><ArrowLeft /> Trở về trang chủ</Link></div>
}
