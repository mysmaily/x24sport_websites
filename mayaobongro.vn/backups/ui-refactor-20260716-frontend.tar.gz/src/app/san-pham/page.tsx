import { ChevronLeft, ChevronRight, Search } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'

import { ProductGrid } from '@/components/product-grid'
import { getProducts } from '@/lib/cms'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'Mẫu Áo Bóng Rổ',
  description: 'Khám phá bộ sưu tập mẫu đồng phục bóng rổ thiết kế theo yêu cầu.',
  alternates: { canonical: '/san-pham/' },
}

export default async function CatalogPage({ searchParams }: { searchParams: Promise<{ page?: string; q?: string }> }) {
  const params = await searchParams
  const page = Math.max(1, Number.parseInt(params.page || '1', 10) || 1)
  const search = params.q?.trim() || ''
  const result = await getProducts({ page, limit: 24, search })
  const pageHref = (nextPage: number) => `/san-pham/?${new URLSearchParams({ ...(search ? { q: search } : {}), page: String(nextPage) })}`
  return (
    <div className="catalog-page section-shell">
      <header className="catalog-header">
        <div><p className="eyebrow">X24 / Basketball archive</p><h1>665 CÁCH<br /><span>RA SÂN.</span></h1></div>
        <p>Chọn một thiết kế làm điểm bắt đầu. Màu sắc, logo, tên và số có thể được trao đổi theo yêu cầu thực tế của đội.</p>
      </header>
      <form action="/san-pham/" className="catalog-search" role="search">
        <Search aria-hidden="true" /><label className="sr-only" htmlFor="catalog-q">Tìm mẫu áo</label>
        <input defaultValue={search} id="catalog-q" name="q" placeholder="Tìm theo tên mẫu, màu sắc…" type="search" />
        <button type="submit">Tìm mẫu</button>
      </form>
      <div className="catalog-meta"><b>{result.totalDocs}</b> mẫu phù hợp <span>Trang {result.page}/{Math.max(result.totalPages, 1)}</span></div>
      <ProductGrid products={result.docs} />
      {result.totalPages > 1 ? <nav className="pagination" aria-label="Phân trang sản phẩm">
        {page > 1 ? <Link href={pageHref(page - 1)}><ChevronLeft /> Trang trước</Link> : <span />}
        <span>{page} / {result.totalPages}</span>
        {page < result.totalPages ? <Link href={pageHref(page + 1)}>Trang sau <ChevronRight /></Link> : <span />}
      </nav> : null}
    </div>
  )
}
