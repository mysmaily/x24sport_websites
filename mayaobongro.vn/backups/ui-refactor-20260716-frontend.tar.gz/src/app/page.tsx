import { ArrowDownRight, ArrowRight, CircleDotDashed } from 'lucide-react'
import type { Metadata } from 'next'
import Link from 'next/link'

import { JsonLd } from '@/components/json-ld'
import { LegacyHomeBanner } from '@/components/legacy-home-banner'
import { ProductGrid } from '@/components/product-grid'
import { getLatestPosts, getProducts } from '@/lib/cms'
import { excerpt, SITE_URL, ZALO_URL } from '@/lib/site'

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: 'May Áo Bóng Rổ Thiết Kế Riêng',
  description: 'Khám phá mẫu đồng phục bóng rổ và gửi yêu cầu thiết kế riêng cho đội, câu lạc bộ hoặc trường học.',
  alternates: { canonical: '/' },
}

export default async function HomePage() {
  const [catalog, posts] = await Promise.all([getProducts({ limit: 8 }), getLatestPosts(3)])

  return (
    <>
      <JsonLd data={{ '@context': 'https://schema.org', '@type': 'OnlineStore', name: 'May Áo Bóng Rổ', url: SITE_URL, telephone: '+84989353247' }} />
      <LegacyHomeBanner />
      <section className="home-intro section-shell">
        <div className="home-intro-copy">
          <p className="eyebrow"><CircleDotDashed aria-hidden="true" /> X24 Basketball Uniform Lab</p>
          <h1>MAY ÁO BÓNG RỔ<br /><span>THIẾT KẾ RIÊNG.</span></h1>
          <p className="hero-lead">Mỗi đội có một nhịp chơi. Bộ đồng phục nên kể đúng câu chuyện đó — từ màu sắc, tên số đến tinh thần xuất hiện trên sân.</p>
          <div className="hero-actions">
            <Link className="button button-orange" href="/san-pham/">Khám phá 665 mẫu <ArrowRight /></Link>
            <a className="text-link text-link-large" href={ZALO_URL} rel="noreferrer" target="_blank">Gửi ý tưởng thiết kế <ArrowDownRight /></a>
          </div>
        </div>
        <div className="hero-metrics" aria-label="Thông tin bộ sưu tập">
          <div><b>665</b><span>Mẫu đã lưu trữ</span></div>
          <div><b>01</b><span>Thiết kế riêng cho đội bạn</span></div>
        </div>
      </section>

      <section className="collection section-shell">
        <div className="section-heading">
          <div><p className="eyebrow">Bộ sưu tập / mới cập nhật</p><h2>Chọn một điểm bắt đầu.</h2></div>
          <Link className="text-link text-link-large" href="/san-pham/">Xem toàn bộ <ArrowRight /></Link>
        </div>
        <ProductGrid products={catalog.docs} />
      </section>

      <section className="process-section">
        <div className="section-shell process-grid">
          <div className="process-intro"><p className="eyebrow">Từ ý tưởng đến sân đấu</p><h2>Không chỉ chọn áo.<br />Bạn tạo bản sắc đội.</h2></div>
          {[
            ['01', 'Gửi ý tưởng', 'Chia sẻ màu sắc, logo và mẫu bạn quan tâm.'],
            ['02', 'Chốt thiết kế', 'Rà soát bố cục tên, số và các chi tiết nhận diện.'],
            ['03', 'Xác nhận đặt may', 'Thống nhất thông tin trước khi đưa vào sản xuất.'],
          ].map(([number, title, text]) => <div className="process-step" key={number}><b>{number}</b><h3>{title}</h3><p>{text}</p></div>)}
        </div>
      </section>

      {posts.docs.length ? (
        <section className="journal section-shell">
          <div className="section-heading"><div><p className="eyebrow">Court notes</p><h2>Đọc trước khi đặt may.</h2></div></div>
          <div className="journal-grid">
            {posts.docs.map((post, index) => <article key={post.id}><span>0{index + 1}</span><p>{post.kind === 'post' ? 'Tư vấn' : 'Thông tin'}</p><h3><Link href={post.legacyPath}>{post.title}</Link></h3><div>{excerpt(post.excerpt, 120)}</div><Link className="text-link" href={post.legacyPath}>Đọc bài <ArrowRight /></Link></article>)}
          </div>
        </section>
      ) : null}
    </>
  )
}
