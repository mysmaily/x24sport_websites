import { ArrowUpRight } from 'lucide-react'
import Image from 'next/image'
import Link from 'next/link'
import type { CSSProperties } from 'react'

import type { Product } from '@/lib/cms'
import { excerpt } from '@/lib/site'

export function ProductCard({ product, index = 0 }: { product: Product; index?: number }) {
  const image = product.legacyImages?.[0]
  const href = product.legacyPath || `/${product.slug}/`
  return (
    <article className="product-card" style={{ '--delay': `${Math.min(index, 8) * 55}ms` } as CSSProperties}>
      <Link className="product-media" href={href} aria-label={`Xem ${product.name}`}>
        {image?.url ? (
          <Image
            alt={image.alt || product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1100px) 33vw, 25vw"
            src={image.url}
          />
        ) : <span className="image-fallback" aria-hidden="true">24</span>}
        <span className="card-index">{String(index + 1).padStart(2, '0')}</span>
      </Link>
      <div className="product-copy">
        <p>Thiết kế theo yêu cầu</p>
        <h3><Link href={href}>{product.name}</Link></h3>
        {product.shortDescription ? <span>{excerpt(product.shortDescription, 86)}</span> : null}
        <Link className="text-link" href={href}>Xem mẫu <ArrowUpRight aria-hidden="true" /></Link>
      </div>
    </article>
  )
}
