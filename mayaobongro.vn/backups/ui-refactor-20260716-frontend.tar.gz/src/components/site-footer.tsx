import Link from 'next/link'

import { PHONE_DISPLAY, PHONE_VALUE, ZALO_URL } from '@/lib/site'

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="footer-callout">
        <p>Đội bạn đã có ý tưởng?</p>
        <h2>Đưa bản phác thảo<br />lên sân đấu.</h2>
        <a className="button button-light" href={ZALO_URL} rel="noreferrer" target="_blank">Trao đổi qua Zalo</a>
      </div>
      <div className="footer-grid">
        <div>
          <div className="footer-mark">X24 / BASKETBALL</div>
          <p>Trang phục bóng rổ thiết kế riêng cho đội, câu lạc bộ và trường học.</p>
        </div>
        <div>
          <b>Khám phá</b>
          <Link href="/san-pham/">Mẫu áo bóng rổ</Link>
          <Link href="/bang-gia-may-ao-bong-ro/">Bảng giá đặt may</Link>
          <Link href="/blog/">Góc tư vấn</Link>
        </div>
        <div>
          <b>Liên hệ</b>
          <a href={`tel:${PHONE_VALUE}`}>{PHONE_DISPLAY}</a>
          <a href={ZALO_URL} rel="noreferrer" target="_blank">Zalo tư vấn</a>
        </div>
      </div>
      <div className="footer-legal">© {new Date().getFullYear()} MayAoBongRo.vn · X24 Sport</div>
    </footer>
  )
}
