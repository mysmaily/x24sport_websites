import type { Product } from '@/lib/cms'

import { ProductCard } from './product-card'

export function ProductGrid({ products }: { products: Product[] }) {
  if (!products.length) return <div className="empty-state"><b>Chưa tìm thấy mẫu phù hợp.</b><p>Thử một tên hoặc màu sắc khác.</p></div>
  return <div className="product-grid">{products.map((product, index) => <ProductCard index={index} key={product.id} product={product} />)}</div>
}
