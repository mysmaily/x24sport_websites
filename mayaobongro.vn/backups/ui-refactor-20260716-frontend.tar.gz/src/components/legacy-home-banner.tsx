import Link from 'next/link'

const CDN = 'https://cdn.mayaobongro.vn/wp-content/uploads/2026/07'

const slides = [
  { id: 1, alt: 'Banner áo bóng rổ học sinh MayAoBongRo.vn' },
  { id: 2, alt: 'Đồng phục bóng rổ thiết kế cho đội học sinh' },
  { id: 3, alt: 'Mẫu áo bóng rổ học sinh thiết kế riêng' },
]

export function LegacyHomeBanner() {
  return (
    <section className="legacy-banner" aria-label="Bộ sưu tập đồng phục bóng rổ học sinh">
      <Link href="/mau-ao-bong-ro/" aria-label="Xem các mẫu áo bóng rổ">
        {slides.map((slide, index) => (
          <picture className={`legacy-banner-slide legacy-banner-slide-${index + 1}`} key={slide.id}>
            <source media="(max-width: 640px)" srcSet={`${CDN}/mayaobongro-student-hero-${slide.id}-mobile-20260712.webp`} />
            <source media="(max-width: 1100px)" srcSet={`${CDN}/mayaobongro-student-hero-${slide.id}-tablet-20260712.webp`} />
            <img
              alt={slide.alt}
              decoding="async"
              fetchPriority={index === 0 ? 'high' : 'auto'}
              height="560"
              loading={index === 0 ? 'eager' : 'lazy'}
              src={`${CDN}/mayaobongro-student-hero-${slide.id}-desktop-20260712.webp`}
              width="1920"
            />
          </picture>
        ))}
      </Link>
      <div className="legacy-banner-dots" aria-hidden="true"><i /><i /><i /></div>
    </section>
  )
}
