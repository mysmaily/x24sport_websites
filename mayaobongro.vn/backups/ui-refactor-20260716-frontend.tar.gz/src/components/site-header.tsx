import { Menu, Phone, X } from 'lucide-react'
import Link from 'next/link'

import { PHONE_DISPLAY, PHONE_VALUE, ZALO_URL } from '@/lib/site'

const links = [
  { href: '/mau-ao-bong-ro/', label: 'Mẫu áo' },
  { href: '/dat-may-ao-bong-ro/', label: 'Đặt may' },
  { href: '/bang-gia-may-ao-bong-ro/', label: 'Bảng giá' },
  { href: '/chat-lieu-va-bang-size-ao-bong-ro/', label: 'Vải & size' },
  { href: '/lien-he/', label: 'Liên hệ' },
]

export function SiteHeader() {
  return (
    <>
      <div className="signal-bar">
        <span>Thiết kế đồng phục bóng rổ theo yêu cầu</span>
        <a href={`tel:${PHONE_VALUE}`}><Phone aria-hidden="true" /> {PHONE_DISPLAY}</a>
      </div>
      <header className="site-header">
        <Link className="wordmark" href="/" aria-label="May Áo Bóng Rổ — Trang chủ">
          <img
            alt="May Áo Bóng Rổ – VN"
            height="44"
            src="https://cdn.mayaobongro.vn/wp-content/uploads/2026/07/may-ao-bong-ro-logo.svg"
            width="287"
          />
        </Link>
        <nav className="desktop-nav" aria-label="Điều hướng chính">
          {links.map((link) => <Link key={link.href} href={link.href}>{link.label}</Link>)}
        </nav>
        <a className="button button-dark header-cta" href={ZALO_URL} rel="noreferrer" target="_blank">
          Gửi mẫu qua Zalo
        </a>
        <details className="mobile-menu">
          <summary aria-label="Mở menu"><Menu className="menu-open" /><X className="menu-close" /></summary>
          <nav aria-label="Điều hướng di động">
            {links.map((link) => <Link key={link.href} href={link.href}>{link.label}</Link>)}
            <a href={ZALO_URL} rel="noreferrer" target="_blank">Gửi mẫu qua Zalo</a>
          </nav>
        </details>
      </header>
    </>
  )
}
