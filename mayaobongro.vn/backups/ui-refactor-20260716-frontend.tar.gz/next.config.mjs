/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone',
  trailingSlash: true,
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'cdn.mayaobongro.vn' },
      { protocol: 'https', hostname: 'mayaobongro.vn' },
      { protocol: 'https', hostname: 'wp.mayaobongro.vn' },
      { protocol: 'https', hostname: 'static.x24sport.vn' },
    ],
  },
}

export default nextConfig
